﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Data;

namespace WebInstance.Models
{
    //数据库连接类
    public class Connection
    {
        public static Connection mConn = null;

        //数据库连接字符串
        public static string conn_str = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=F:\web课程设计\WebInstance\WebInstance\App_Data\Fat246.mdf;Integrated Security=True";

        private SqlConnection conn = null;

        //将数据库链接类设置成单利
        private Connection()
        { 
            conn = new SqlConnection(conn_str);
            conn.Open();
        }

        //检查登陆
        public bool checkLogin(string name,string password)
        {

            //sql语句
            string cmd_str =string.Format("select * from user_info where name='{0}' and password='{1}'",name,password);

            SqlCommand cmd = new SqlCommand(cmd_str,conn);

            SqlDataReader sdr = cmd.ExecuteReader();

            if (sdr.Read())
            {
                sdr.Close();
                return true;
            }
            
            sdr.Close();
            return false;
        }

        //注册用户
        public bool toRegister(string name, string password,string email,string phone)
        {

            if (email == null) email = "";
            if (phone == null) phone = "";

            string cmd_str = string.Format("insert into user_info values('{0}','{1}','{2}','{3}')",name,password,email,phone);

            SqlCommand cmd = new SqlCommand(cmd_str,conn);

            int i = cmd.ExecuteNonQuery();

            if (i > 0) return true;

            return false;
        }

        //删除物品
        public bool toDeleteGoods(int id)
        {
            string cmd_str = string.Format("delete from cart where id={0}",id);

            SqlCommand cmd = new SqlCommand(cmd_str,conn);

            int i = cmd.ExecuteNonQuery();

            if (i > 0) return true;

            return false;
        }
        
        //返回购物车
        public DataSet getDataSet(string name)
        {
            string sql_str = string.Format("select * from cart where name='{0}'",name);

            SqlDataAdapter sda = new SqlDataAdapter(sql_str,conn);

            DataSet ds = new DataSet();

            sda.Fill(ds);

            return ds;
        }

        //返回订单
        public DataSet getOrder(string name)
        {
            string sql_str = string.Format("select * from gorder where name='{0}'", name);

            SqlDataAdapter sda = new SqlDataAdapter(sql_str, conn);

            DataSet ds = new DataSet();

            sda.Fill(ds);

            return ds;
        }

        public DataSet getGoodsDataSet(string gclass)
        {
            string sql_str = string.Format("select * from goods where goods_class='{0}'", gclass);

            SqlDataAdapter sda = new SqlDataAdapter(sql_str, conn);

            DataSet ds = new DataSet();

            sda.Fill(ds);

            return ds;
        }

        //计算购物车的商品总价
        public double getTotal(string name)
        {
            string cmd_str = string.Format("select goods_prise from cart where name='{0}'",name);

            SqlCommand cmd = new SqlCommand(cmd_str,conn);

            SqlDataReader sdr = cmd.ExecuteReader();

            //总价
            double sum = 0.00;

            while (sdr.Read())
            {
                sum += Convert.ToDouble(sdr[0]);
            }

            sdr.Close();

            return sum;
        }

        //计数购物出里的商品个数
        public int getCount(string name)
        {
            string cmd_str = string.Format("select goods_prise from cart where name='{0}'", name);

            SqlCommand cmd = new SqlCommand(cmd_str, conn);

            SqlDataReader sdr = cmd.ExecuteReader();

            //总价
            int sum = 0;

            while (sdr.Read())
            {
                sum ++;
            }

            sdr.Close();

            return sum;
        }

        //清空购物车
        public int emptyCart(string name)
        {
            string cmd_str = string.Format("delete from cart where name='{0}'", name);

            SqlCommand cmd = new SqlCommand(cmd_str, conn);

            int i = cmd.ExecuteNonQuery();

            return i;
        }

        //将指定的货物添加到购物车
        public bool addToCart(string name,string goods_name)
        {
            //首先从商品列表当中查找到指定的物品
            string cmd_str = string.Format("select * from goods where goods_name='{0}'",goods_name);

            //商品信息
            string goods_prise = null;
            string goods_pic = null;
            string goods_des = null;


            SqlCommand cmd = new SqlCommand(cmd_str,conn);

            SqlDataReader sdr = cmd.ExecuteReader();
            
            if (sdr.Read())
            {
                goods_prise = sdr[3].ToString();
                goods_pic = sdr[4].ToString();
                goods_des = sdr[5].ToString();
            }
            else
            {
                return false;
            }

            sdr.Close();

            cmd_str = string.Format("insert into cart values('{0}','{1}',{2},'{3}','{4}')",name,goods_name,goods_prise,goods_pic,goods_des);

            cmd.CommandText = cmd_str;

            int i = cmd.ExecuteNonQuery();
            if (i > 0) return true;

            return false;
        }

        //添加订单
        public bool addOrder(string name,float order_prise,string order_des)
        {
            string sql_str = string.Format("insert into gorder values('{0}',{1},'{2}','{3}')", DateTime.Now.ToString(),order_prise,order_des,name);

            SqlCommand cmd = new SqlCommand(sql_str,conn);

            int i = cmd.ExecuteNonQuery();
            if (i > 0)
            {
                return true;
            }

            return false;
        }


        //插入商品
        public bool addGoods(string goods_class,string goods_name,float goods_prise,string goods_pic,string goods_des)
        {

            string cmd_str = string.Format("insert into goods values('{0}','{1}',{2},'{3}','{4}')",goods_class,goods_name,goods_prise,goods_pic,goods_des);

            SqlCommand cmd = new SqlCommand(cmd_str,conn);

            int i = cmd.ExecuteNonQuery();

            if (i > 0) return true;
            return false;
        }

        /*
        public bool addGoods(string sql,SqlParameter param)
        {
            SqlCommand cmd = new SqlCommand(sql,conn);

            cmd.Parameters.Add(param);

            try
            {
                if (cmd.ExecuteNonQuery() > 0) return true;
            }
            catch(Exception e)
            {
                return false;
            }

            return false;
        }

    */

        //获得单例
        public static Connection getConnection()
        {
            if (mConn == null) mConn = new Connection();
            return mConn;
        }
    }
}