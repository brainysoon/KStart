﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using WebInstance.Controllers;

namespace WebInstance.Views
{
    public partial class Login : System.Web.UI.Page
    {

        //用户记录用户名和密码的属性
        private string name=null;
        private string password=null;

        protected void Page_Load(object sender, EventArgs e)
        {

            //解决验证控件的错误
            UnobtrusiveValidationMode = UnobtrusiveValidationMode.None;
        }

        protected void Button1_Click(object sender, EventArgs e)
        {

            //首先拿到用户名，密码
            getNamePassword();

            //交给 数据控制层处理
            if (new toLogin(name, password).checkLogin())
            {
                Session["name"] = name;
                Session["isLog"] = "true";
                Response.Redirect("Index.aspx", true);
            }
            else
            {
                Response.Write("<script>alert('用户名或密码错误！')</script>");
            }
        }
        

        //从输入框中拿到用户名和密码
        private void getNamePassword()
        {
            name = TextBox1.Text.ToString().Trim();
            password = TextBox2.Text.ToString().Trim();
        }
    }
}