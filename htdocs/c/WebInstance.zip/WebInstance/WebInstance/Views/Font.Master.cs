﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using WebInstance.Controllers;
using WebInstance.Models;

namespace WebInstance.Views
{
    public partial class Font : System.Web.UI.MasterPage
    {

        protected void Page_Load(object sender, EventArgs e)
        {

            //设置登陆信息
            setInfo();

            //
            countTotal();

        }

        private void setInfo()
        {
            if (Session["isLog"] == null || !Session["isLog"].Equals("true"))
            {
                LinkButton1.Text = "登录";
                LinkButton2.Text = "";
            }
            else
            {
                LinkButton1.Text = Session["name"].ToString();
                LinkButton2.Text = "注销";
            }
        }

        //计算购物车的总价
        private void countTotal()
        {
            object name = Session["name"];

            if (name == null) return;

            //商品总价
            toCountTotal tc= new toCountTotal(name.ToString());
            double total =tc.getTotal();
            int sum = tc.getCount();

            Label1.Text = total + "";
            Label2.Text = sum + "";

        }

        protected void LinkButton1_Click(object sender, EventArgs e)
        {
            if (LinkButton1.Text == "登录")
            {
                Response.Redirect("Login.aspx", true);
            }
            else
            {
                Response.Redirect("Order.aspx", true);
            }
        }

        protected void LinkButton2_Click(object sender, EventArgs e)
        {
            Session["isLog"] = "false";
            Session["name"] = "null";
            setInfo();
        }

        protected void LinkButton4_Click(object sender, EventArgs e)
        {
            object name = Session["name"];
            if (name == null || name.ToString() == "null")
            {
                Response.Write("<script>alert('请先登录！')</script>");
                return;
            }

            Connection.getConnection().emptyCart(name.ToString());
            countTotal();
        }

        protected void LinkButton5_Click(object sender, EventArgs e)
        {
            object name = Session["name"];
            if (name == null || name.ToString() == "null")
            {
                Response.Write("<script>alert('请先登录！')</script>");
                return;
            }

            if (Connection.getConnection().addOrder(name.ToString(), (float)new toCountTotal(name.ToString()).getTotal(), "快速购买"))
            {
                Response.Write("<script>alert('购买成功！')</script>");
                Connection.getConnection().emptyCart(name.ToString());
            }
            else
            {
                Response.Write("<script>alert('购买失败，请及时联系管理员！')</script>");
            }
        }
    }
}