﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Data.Common;
using System.Configuration;
using WebInstance.Models;

namespace WebInstance.Views
{
    public partial class WebForm1 : System.Web.UI.Page
    {

        //文件保存的目录
        private string goods_pic=null;

        //商品的一些其他信息
        private string goods_class = null;
        private string goods_name = null;
        private float goods_prise = 0.00f;
        private string goods_des = null;

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {

            getInfo();

            if (Connection.getConnection().addGoods(goods_class, goods_name, goods_prise, goods_pic, goods_des))
            {
                Response.Write("<script>alert('插入成功！')</script>");
            }
            else
            {
                Response.Write("<script>alert('插入失败！')</script>");
            }

            /*
            if (FileUpload1.HasFile)
            {
                string upPath = "../images/";  //上传文件路径
                int upLength = 5;        //上传文件大小
                string upFileType = "|image/bmp|image/x-png|image/pjpeg|image/gif|image/png|image/jpeg|";

                string fileContentType = FileUpload1.PostedFile.ContentType;    //文件类型

                if (upFileType.IndexOf(fileContentType.ToLower()) > 0)
                {
                    string name = FileUpload1.PostedFile.FileName;                  // 客户端文件路径

                    FileInfo file = new FileInfo(name);

                    string fileName = DateTime.Now.ToString("yyyyMMddhhmmssfff") + file.Extension; // 文件名称，当前时间（yyyyMMddhhmmssfff）
                    string webFilePath = Server.MapPath(upPath) + fileName;        // 服务器端文件路径

                    FilePath = upPath + fileName;   //页面中使用的路径

                    if (!File.Exists(webFilePath))
                    {
                        if ((FileUpload1.FileBytes.Length / (1024 * 1024)) > upLength)
                        {
                            ClientScript.RegisterStartupScript(this.GetType(), "upfileOK", "alert('大小超出 " + upLength + " M的限制，请处理后再上传！');", true);
                            return;
                        }

                        try
                        {
                            FileUpload1.SaveAs(webFilePath);                                // 使用 SaveAs 方法保存文件

                           
                            this.Image1.ImageUrl = FilePath;

                            getInfo();

                            //以流的形式打开
                            FileStream fs = new FileStream(webFilePath, FileMode.Open, FileAccess.Read);

                            BinaryReader br = new BinaryReader(fs);

                            byte[] img = br.ReadBytes(Convert.ToInt32(fs.Length));

                            string sql = string.Format("insert into goods values('{0}','{1}',{2},@goods_pic,'{3}')", goods_class, goods_name, goods_prise, goods_des);


                            Connection.getConnection().addGoods(sql, new SqlParameter("@goods_pic", img));

                            ClientScript.RegisterStartupScript(this.GetType(), "upfileOK", "alert('提示：插入成功！');", true);

                        }
                        catch (Exception ex)
                        {
                            ClientScript.RegisterStartupScript(this.GetType(), "upfileOK", "alert('提示：文件上传失败" + ex.Message + "');", true);
                        }
                    }
                    else
                    {
                        ClientScript.RegisterStartupScript(this.GetType(), "upfileOK", "alert('提示：文件已经存在，请重命名后上传');", true);
                    }
                }
                else
                {
                    ClientScript.RegisterStartupScript(this.GetType(), "upfileOK", "alert('提示：文件类型不符" + fileContentType + "');", true);
                    
                }
            }*/

        }
        
        public void getInfo()
        {
            goods_class = TextBox2.Text.ToString().Trim();
            goods_name = TextBox1.Text.ToString().Trim();
            goods_prise =(float) Convert.ToDouble(TextBox3.Text.ToString().Trim());
            goods_des = TextBox4.Text.ToString().Trim();
            goods_pic =@"../images/" +RadioButtonList1.SelectedValue;
        }

        protected void RadioButtonList1_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }
    }
}