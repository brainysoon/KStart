﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using WebInstance.Controllers;

namespace WebInstance.Views
{
    public partial class Register : System.Web.UI.Page
    {

        //保存输入的数据
        private string name = null;
        private string password = null;
        private string email = null;
        private string phone = null;

        protected void Page_Load(object sender, EventArgs e)
        {
            //解决验证控件的错误
            UnobtrusiveValidationMode = UnobtrusiveValidationMode.None;
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            //首先获得数据
            getInfo();

            if (new toRegsiter(name,password,email,phone).regsiterResult())
            {
                Session["name"] = name;
                Session["isLog"] = "true";
                Response.Redirect("Index.aspx", true);
            }
            else
            {
                Response.Write("<script>alert('注册失败！请及时联系管理员！')</script>");
            }
        }

        private void getInfo()
        {
            name = TextBox3.Text.ToString().Trim();
            password = TextBox4.Text.ToString().Trim();
            email = TextBox1.Text.ToString().Trim();
            phone = TextBox2.Text.ToString().Trim();
        }
    }
}