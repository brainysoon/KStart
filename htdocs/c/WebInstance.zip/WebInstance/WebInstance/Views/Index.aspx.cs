﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using WebInstance.Models;
using WebInstance.Controllers;

namespace WebInstance
{
    public partial class Index : System.Web.UI.Page
    {

        //类别
        private string gclass = "瑜伽";

        //创建一个分页数据源的对象且一定要声明为静态
        protected static PagedDataSource pds = new PagedDataSource();

        protected void Page_Load(object sender, EventArgs e)
        {
            //解决验证控件的错误
            UnobtrusiveValidationMode = UnobtrusiveValidationMode.None;

            if (!IsPostBack)
            {
                //调用自定义方法绑定数据到控件（为以后做MVC打下基础）
                BindDataList(0);
            }

        }

        //对datelist进行数据绑定
        private void BindDataList(int currentpage)
        {
            pds.AllowPaging = true;//允许分页
            pds.PageSize = 3;//每页显示3条数据
            pds.CurrentPageIndex = currentpage;//当前页为传入的一个int型值
            

            //拿到Dataset
            DataSet ds = Connection.getConnection().getGoodsDataSet(gclass);

            pds.DataSource = ds.Tables[0].DefaultView;//把数据集中的数据放入分页数据源中
            DataList2.DataSource = pds;//绑定Datalist
            DataList2.DataBind();

        }

        protected void DataList1_ItemCommand(object source, DataListCommandEventArgs e)
        {
            switch (e.CommandName)
            {
                //以下5个为 捕获用户点击 上一页 下一页等时发生的事件
                case "first"://第一页
                    pds.CurrentPageIndex = 0;
                    BindDataList(pds.CurrentPageIndex);
                    break;
                case "pre"://上一页
                    pds.CurrentPageIndex = pds.CurrentPageIndex - 1;
                    BindDataList(pds.CurrentPageIndex);
                    break;
                case "next"://下一页
                    pds.CurrentPageIndex = pds.CurrentPageIndex + 1;
                    BindDataList(pds.CurrentPageIndex);
                    break;
                case "last"://最后一页
                    pds.CurrentPageIndex = pds.PageCount - 1;
                    BindDataList(pds.CurrentPageIndex);
                    break;
                case "search"://页面跳转页
                    if (e.Item.ItemType == ListItemType.Footer)
                    {
                        int PageCount = int.Parse(pds.PageCount.ToString());
                        TextBox txtPage = e.Item.FindControl("txtPage") as TextBox;
                        int MyPageNum = 0;
                        if (!txtPage.Text.Equals(""))
                            MyPageNum = Convert.ToInt32(txtPage.Text.ToString());
                        if (MyPageNum <= 0 || MyPageNum > PageCount)
                        {
                            Response.Write("<script>alert('请输入页数并确定没有超出总页数！')</script>");
                            txtPage.Text = "";
                        }
                        else
                            BindDataList(MyPageNum - 1);
                    }
                    break;
            }
            if (e.CommandName == "add")
            {
                object name = Session["name"];
                if (name == null||name.ToString()=="null")
                {
                    ScriptManager.RegisterStartupScript(UpdatePanel1, UpdatePanel1.GetType(), "", "alert('提示：请先登录！');", true);

                    return;
                }

                string goods_name = e.CommandArgument.ToString();

                if (new toAdd(name.ToString(), goods_name).addToCart())
                {
                    ScriptManager.RegisterStartupScript(UpdatePanel1, UpdatePanel1.GetType(), "", "alert('提示：商品添加成功！');", true);

                }
                else
                {
                    ScriptManager.RegisterStartupScript(UpdatePanel1, UpdatePanel1.GetType(), "", "alert('提示：商品添加成功！');", true);

                }
            }
        }

        protected void DataList1_ItemDataBound(object sender, DataListItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Footer)
            {
                //以下六个为得到脚模板中的控件,并创建变量.
                Label CurrentPage = e.Item.FindControl("labCurrentPage") as Label;
                Label PageCount = e.Item.FindControl("labPageCount") as Label;
                LinkButton FirstPage = e.Item.FindControl("lnkbtnFirst") as LinkButton;
                LinkButton PrePage = e.Item.FindControl("lnkbtnFront") as LinkButton;
                LinkButton NextPage = e.Item.FindControl("lnkbtnNext") as LinkButton;
                LinkButton LastPage = e.Item.FindControl("lnkbtnLast") as LinkButton;
                CurrentPage.Text = (pds.CurrentPageIndex + 1).ToString();//绑定显示当前页
                PageCount.Text = pds.PageCount.ToString();//绑定显示总页数
                if (pds.IsFirstPage)//如果是第一页,首页和上一页不能用
                {
                    FirstPage.Enabled = false;
                    PrePage.Enabled = false;
                }
                if (pds.IsLastPage)//如果是最后一页"下一页"和"尾页"按钮不能用
                {
                    NextPage.Enabled = false;
                    LastPage.Enabled = false;
                }
            }
        }
        


        protected void DataList1_ItemCommand1(object source, DataListCommandEventArgs e)
        {
            this.gclass = e.CommandArgument.ToString();
            BindDataList(pds.CurrentPageIndex);
        }

    }
    
}