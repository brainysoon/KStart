﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using WebInstance.Controllers;
using WebInstance.Models;

namespace WebInstance.Controllers
{
    public class toCountTotal
    {

        //记录是谁的购物车
        private string name=null;

        //保存数据库单利
        private Connection mConn = null;
        
        public toCountTotal(string name)
        {
            this.name = name;

            //获得数据库单利
            this.mConn = Connection.getConnection();
        }

        //计算商品总价
        public double getTotal()
        {
            
            return mConn.getTotal(name);
        }

        //计算商品个数
        public int getCount()
        {
            return mConn.getCount(name);
        }
    }
}