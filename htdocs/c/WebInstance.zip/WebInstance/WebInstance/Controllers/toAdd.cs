﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using WebInstance.Models;

namespace WebInstance.Controllers
{

    public class toAdd
    {
        //保存添加的商品的名字和人的名字
        private string goods_name = null;
        private string name = null;

        //单粒1
        private Connection mConn;
        public toAdd(string name,string goods_name)
        {
            this.goods_name = goods_name;
            this.name = name;

            //获得数据库单利
            this.mConn = Connection.getConnection();
        }

        //将制定的商品添加到购物车
        public bool addToCart()
        {
            if (mConn.addToCart(name,goods_name)) return true;
            return false;
        }
    }
}