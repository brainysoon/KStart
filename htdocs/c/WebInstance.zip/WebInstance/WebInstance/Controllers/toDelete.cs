﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using WebInstance.Models;

namespace WebInstance.Controllers
{
    public class toDelete
    {
        //记录物品
        private int id;
        
        //数据库单利
        private Connection mConn = null;
        public toDelete(int id)
        {
            this.id = id;

            //获得数据库单利
            this.mConn = Connection.getConnection();
        }

        public bool excutDeleteGoods()
        {

            if (mConn.toDeleteGoods(id)) return true;

            return false;
        }
    }
}