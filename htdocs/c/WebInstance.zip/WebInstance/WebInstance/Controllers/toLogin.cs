﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using WebInstance.Models;

namespace WebInstance.Controllers
{
    
    public class toLogin
    {

        //数据库层
        private Connection mConn = null;
        
        //记录输入的用户名以及密码
        private string name=null;
        private string password = null;

        public toLogin(string name,string password)
        {
            this.name = name;
            this.password = password;

            //拿到数据库单利
            mConn = Connection.getConnection();
        }

        //到数据库里面去校验，用户名和密码是否匹配
        public bool checkLogin()
        {
            if (mConn.checkLogin(name, password)) return true;
            return false;
        }
    }
}