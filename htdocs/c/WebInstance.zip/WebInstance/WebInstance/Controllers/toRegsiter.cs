﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using WebInstance.Models;

namespace WebInstance.Controllers
{
    public class toRegsiter
    {
        //保存输入的数据
        private string name = null;
        private string password = null;
        private string email = null;
        private string phone = null;

        //获得数据库单利
        private Connection mConn=null;

        public toRegsiter(string name,string password,string email,string phone)
        {
            this.name = name;
            this.password = password;
            this.email = email;
            this.phone = phone;

            //拿到数据库对象
            mConn = Connection.getConnection();
        }

        public bool regsiterResult()
        {

            if (mConn.toRegister(name, password, email, phone)) return true;

            return false;
        }
    }
}