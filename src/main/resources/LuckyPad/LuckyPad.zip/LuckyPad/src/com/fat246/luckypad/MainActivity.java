package com.fat246.luckypad;

import java.util.Random;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;

import com.fat246.view.LuckyPadView;


public class MainActivity extends Activity {

	private LuckyPadView id_luckypadview;
	private ImageView id_imageview;
	
	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initView();
        setListener();
    }


	private void setListener() {
		id_imageview.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				if (!id_luckypadview.isStart()){
					id_imageview.setImageResource(R.drawable.stop);
					Random random=new Random();
					
					id_luckypadview.luckyStart(random.nextInt()%6);
				}else {
					if (!id_luckypadview.isShouldEnd()){
						id_imageview.setImageResource(R.drawable.start);
						id_luckypadview.luckyEnd();
					}
				}
				
			}
		});
	}


	private void initView() {
		id_luckypadview=(LuckyPadView)findViewById(R.id.id_luckypadview);
		id_imageview=(ImageView)findViewById(R.id.id_imageview);
	}
}
