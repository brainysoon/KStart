package com.fat246.minions;


import DataBase.mDataBaseHelper;
import android.app.Activity;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class Regster extends Activity {

	private ImageView regsterHeadIcon;
	private EditText regsterUserName;
	private EditText regsterUserPassword;
	private EditText regsterUserPasswordAgain;
	private Button regsterButton;
	private TextView textToast;
	
	//ȫ�ֱ���
	private String name;
	private String password;
	private String passwordAgain;
	private static final String table="UserInfo";
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_regster);
		initView();
		taskBeforeClick();
	}

	//���֮��Ҫ������
	private void taskAfterClick() {
		
		name=regsterUserName.getText().toString().trim();
		password=regsterUserPassword.getText().toString().trim();
		passwordAgain=regsterUserPasswordAgain.getText().toString().trim();
		
		if (name.equals("")){
			showToast("�������˻���");
		}else if (password.equals("")){
			showToast("����������");
		}else if (!password.equals(passwordAgain)){
			showToast("��ȷ������");
		}else if (checkUser()){
			showToast("�˻����Ѿ�����");
		}else{
			try{
				mDataBaseHelper mhelper=new mDataBaseHelper(this, "foundtion.db", null, 1);
				SQLiteDatabase db=mhelper.getWritableDatabase();
				db.execSQL(String.format("insert into UserInfo(name,password) values('%s','%s')", name,password));
				mhelper.close();
				db.close();
				Toast.makeText(this, "���ӳɹ�", Toast.LENGTH_SHORT).show();
			}catch(Exception e){
				e.printStackTrace();
			}
		}
		return ;
	}

	//��̬��ʾ��¼��Ϣ
		private void showToast(String content) {
			Toast toast=Toast.makeText(this, content, Toast.LENGTH_SHORT);
			LayoutInflater inflater=LayoutInflater.from(this);
			View view=inflater.inflate(R.layout.toast, null);
			textToast=(TextView)view.findViewById(R.id.textToast);
			textToast.setText(content);
			toast.setGravity(Gravity.CENTER, 0, 0);
			toast.setView(view);
			toast.show();
		}
		
	//�����ݿ���֤ �û����ǲ����Ѿ�����
	private boolean checkUser() {
		mDataBaseHelper mhelper=new mDataBaseHelper(this, "foundtion.db", null, 1);
		SQLiteDatabase db=mhelper.getReadableDatabase();
		Cursor cursor=db.rawQuery("select _id from UserInfo	where name='"+name+"'", null);
		if (!cursor.moveToFirst()){
			mhelper.close();
			cursor.close();
			db.close();
			return  false;
		}
		mhelper.close();
		cursor.close();
		db.close();
		return true;
	}

	//���֮ǰ��Ҫ������
	private void taskBeforeClick() {
		regsterButton.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				taskAfterClick();
			}
		});
		
	}

	//��ʼ��View
	private void initView() {
		
		regsterHeadIcon=(ImageView)findViewById(R.id.regsterHeadIcon);
		regsterUserName=(EditText)findViewById(R.id.regsterUserName);
		regsterUserPassword=(EditText)findViewById(R.id.regsterUserPassword);
		regsterUserPasswordAgain=(EditText)findViewById(R.id.regsterUserPasswordAgain);
		regsterButton=(Button)findViewById(R.id.regsterButton);
		
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.regster, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
}
