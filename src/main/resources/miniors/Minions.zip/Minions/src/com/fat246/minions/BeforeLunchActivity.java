package com.fat246.minions;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Timer;
import java.util.TimerTask;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;
import android.widget.ViewFlipper;


public class BeforeLunchActivity extends Activity {
	
	//����ͼƬ�������Ϣ
	private static final String foreHead="http://www.fat246.com/miniors/pic";
	private String foreHeadName;
	private String dateName="";
	private Timer timer;
	private int times=1;
	
	//���ڻ����¼�
	private float startX;
	
	//ͼƬ����
	private Bitmap picBitmap;
	
	//View����
	private Button buttonLunch;
	private ViewFlipper viewFlipper;
	private ImageView lunchImage;
	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_before_lunch);
        initView();
        iniPicForeName();
        taskBeforeLunch();
        init();
    }

    //��ͼƬ��URLǰ׺Ū��
    private void iniPicForeName() {
    	try{
			SimpleDateFormat saf=new SimpleDateFormat("yyyyMMdd");
			dateName=saf.format(new java.util.Date());
//			Toast.makeText(this, dateName, Toast.LENGTH_SHORT).show();	//��֤ʱ��
			foreHeadName=foreHead+dateName;
		}
		catch(Exception e){
		}
	}

	//��ʼ�����Զ�����ViewFillper
    private void init() {
		viewFlipper.setFlipInterval(3000);
		viewFlipper.setInAnimation(this, R.anim.right_in);
		viewFlipper.setOutAnimation(this, R.anim.right_out);
		viewFlipper.startFlipping();
	}

	//��ʼ��View
    private void initView() {
		buttonLunch=(Button)findViewById(R.id.buttonLunch);
		viewFlipper=(ViewFlipper)findViewById(R.id.viewFlipper);
	}
    
    //��д������Ӧ�������ڻ����¼�
    @Override
	public boolean onTouchEvent(MotionEvent event) {
    	 switch (event.getAction()) {
         case MotionEvent.ACTION_DOWN:
             startX = event.getX();
             viewFlipper.stopFlipping();
             break;
         case MotionEvent.ACTION_UP:
  
             if (event.getX() - startX>100) { // ���һ���
            	 viewFlipper.setInAnimation(this, R.anim.left_in);
				 viewFlipper.setOutAnimation(this, R.anim.left_out);
            	 viewFlipper.showNext();          
                 
             } else if (startX-event.getX() >100 ) { // ���󻬶�
                 viewFlipper.setInAnimation(this, R.anim.right_in);
                 viewFlipper.setOutAnimation(this,R.anim.right_out); 
            	 viewFlipper.showPrevious();                 
             }
             break;
         case MotionEvent.ACTION_MOVE:
        	 init();
        	 break;
         }
  
		return super.onTouchEvent(event);
	}

    //handler �� ���ڶ�ʱ��
    Handler hand=new Handler(){
		@Override
		public void handleMessage(Message msg) {
			// TODO Auto-generated method stub
			super.handleMessage(msg);
			
			try{
				picBitmap=(Bitmap)msg.obj;
				if (picBitmap==null){
					Toast.makeText(BeforeLunchActivity.this, "ͼƬ����ʧ��", Toast.LENGTH_SHORT).show();
				}
				else{
					//��ViewFlipper��̬����ͼƬ
					lunchImage=new ImageView(BeforeLunchActivity.this);
					lunchImage.setImageBitmap(picBitmap);
					viewFlipper.addView(lunchImage);
				}
					
			}
			
			catch(Exception e){
				e.printStackTrace();
			}
		}
		
	};
	

	//��һЩ�����ڽ���֮ǰ
    private void taskBeforeLunch() {
    	//ͨ�������ڲ��࣬����button�ĵ���¼�
    	buttonLunch.setOnClickListener(new OnClickListener() {
    				
    		@Override
    		public void onClick(View arg0) {
    			logIn();
    			//System.exit(0);
    		}
    	});
    			
    	if (loadPic()){
    		
    	}
    	else {
    		
    	}
    	
    	
		
	}
    
    //��������ͼƬ
    private boolean loadPic() {
		
		{
				TimerTask tTask=new TimerTask() {
				@Override
				public void run() {
					if (foreHeadName.equals("")) return ;			
					Message msg=new Message();
					String url=foreHeadName+String.format("%02d", times++)+".png";
					Bitmap bitmap=null;
					URL Url;
					InputStream is = null;
					BufferedInputStream bis = null;
					try {
						Url=new URL(url);
						is=Url.openStream();
						bis=new BufferedInputStream(is);
						bitmap=BitmapFactory.decodeStream(bis);
					} catch (MalformedURLException e) {
						
						e.printStackTrace();
					} catch (IOException e) {
						
						e.printStackTrace();
					}
					catch(Exception e){
						
					}
					finally{
						try {
							is.close();
							bis.close();
						} catch (Exception e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
					if (bitmap==null){
						timer.cancel();
						return ;
					}
					msg.obj=bitmap;
					msg.what=times;
					hand.sendMessage(msg);
				}
			};
			timer=new Timer();
			timer.schedule(tTask, 0,1);
		}
		return true;
	}

	//��ת����¼ҳ��
    private void logIn() {
		Intent intent=new Intent(this, LogInActivity.class);
		startActivity(intent);
	}

    
	@Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.before_lunch, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
