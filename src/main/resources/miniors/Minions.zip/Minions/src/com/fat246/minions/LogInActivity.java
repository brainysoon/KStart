package com.fat246.minions;

import DataBase.mDataBaseHelper;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class LogInActivity extends Activity {

	//Viewȫ�ֱ���
	private ImageView headIcon;
	private EditText userName;
	private EditText userPassword;
	private CheckBox checkBoxPassword;
	private CheckBox checkBoxState;
	private Button buttonLogIn;
	private Button regster;
	private TextView textToast;
	
	//�û�����
	private String name;
	private String password;
	
	//���ݿ����
	private static final String table="UserInfo";
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_log_in);
		initView();
		taskBeforeClick();
	}

	//����˰�ť���гɹ���֤���������Ҫ������
	private void taskAfterClickAndChecked() {
		if (checkBoxPassword.isChecked()){
			saveInfo(true);
		}
		else {
			saveInfo(false);
		}
	}

	//�����û���Ϣ
	private void saveInfo(boolean flag) {
		
		SharedPreferences spre=getSharedPreferences("logDefault", MODE_PRIVATE);
		Editor editor=spre.edit();
		editor.remove("defaultName");
		editor.remove("logPassword");
		editor.remove("boolPassword");
		if (flag){
			editor.putString("defaultName", userName.getText().toString().trim());
			editor.putString("logPassword", userPassword.getText().toString().trim());
			editor.putBoolean("boolPassword", true);
		}
		else {
			editor.putString("defaultName", userName.getText().toString().trim());
			editor.putBoolean("boolPassword", false);
		}
		editor.commit();
	}

	//���������Ҫ�����£����������ݿ���֤���룬�ȵȡ�
	private void taskAfterClick() {
		name=userName.getText().toString().trim();
		password=userPassword.getText().toString().trim();
		
		//��֤�û���������	
		mDataBaseHelper mhelper =new mDataBaseHelper(this, "foundtion.db", null, 1);
		SQLiteDatabase db=mhelper.getReadableDatabase();
		Cursor cursor=db.rawQuery("select password from UserInfo where name='"+name+"'", null);
		try{
			if(cursor.moveToFirst()){
				if (cursor.getString(0).equals(password)){
					showToast("��¼�ɹ�");
					taskAfterClickAndChecked();
					satrtNewActivity();
				}
				else {
					showToast("��¼ʧ��");
				}
			}
			else {
				showToast("�û���������");
			}
		}
		catch(Exception e){
			e.printStackTrace();
		}
		mhelper.close();
		cursor.close();
		db.close();
	}

	//��̬��ʾ��¼��Ϣ
	private void showToast(String content) {
		Toast toast=Toast.makeText(this, content, Toast.LENGTH_SHORT);
		LayoutInflater inflater=LayoutInflater.from(this);
		View view=inflater.inflate(R.layout.toast, null);
		textToast=(TextView)view.findViewById(R.id.textToast);
		textToast.setText(content);
		toast.setGravity(Gravity.CENTER, 0, 0);
		toast.setView(view);
		toast.show();
	}

	//start a new Actinvity
	private void satrtNewActivity() {
		Intent intent =new Intent(this,ContentActivity.class);
		startActivity(intent);
	}

	//�ٵ��ǰ��һЩ׼������
	private void taskBeforeClick() {
		SharedPreferences spre=getSharedPreferences("logDefault", MODE_PRIVATE);
		userName.setText(spre.getString("defaultName", ""));
		if (spre.getBoolean("boolPassword", false)){
			userPassword.setText(spre.getString("logPassword",""));
			checkBoxPassword.setChecked(true);
		}
		
		//���ü�����
		buttonLogIn.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				taskAfterClick();
			}
		});
		regster.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				Intent intent =new Intent(LogInActivity.this, Regster.class);
				startActivity(intent);
			}
		});
	}

	//��ʼ��View
	private void initView() {
		headIcon=(ImageView)findViewById(R.id.headIcon);
		userName=(EditText)findViewById(R.id.userName);
		userPassword=(EditText)findViewById(R.id.userPassword);
		checkBoxPassword=(CheckBox)findViewById(R.id.checkBoxPassword);
		checkBoxState=(CheckBox)findViewById(R.id.checkBoxState);
		buttonLogIn=(Button)findViewById(R.id.buttonLogIn);
		regster=(Button)findViewById(R.id.regster);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.log_in, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
}
