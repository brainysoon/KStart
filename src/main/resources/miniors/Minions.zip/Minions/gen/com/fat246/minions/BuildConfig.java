/** Automatically generated file. DO NOT MODIFY */
package com.fat246.minions;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}