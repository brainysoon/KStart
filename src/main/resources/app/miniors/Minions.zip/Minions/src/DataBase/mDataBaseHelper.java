package DataBase;

import android.content.Context;
import android.database.DatabaseErrorHandler;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteDatabase.CursorFactory;
import android.database.sqlite.SQLiteOpenHelper;

public class mDataBaseHelper extends SQLiteOpenHelper{

	public mDataBaseHelper(Context context, String name, CursorFactory factory,
			int version) {
		super(context, name, factory, version);
		
	}

	@Override
	public void onCreate(SQLiteDatabase arg0) {
		arg0.execSQL("create table if not exists UserInfo(_id integer primary key autoincrement,name text not null,password text not null)");
		arg0.execSQL("insert into UserInfo(name,password) values('sun','123')");
	}

	@Override
	public void onUpgrade(SQLiteDatabase arg0, int arg1, int arg2) {
		
	}
}
